<?php

echo "province endpoint is here ...";